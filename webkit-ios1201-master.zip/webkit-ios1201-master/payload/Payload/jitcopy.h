#pragma once

void jitcopy(void* gadget, void* stack_check_guard, void* dst, void* src, size_t size);
