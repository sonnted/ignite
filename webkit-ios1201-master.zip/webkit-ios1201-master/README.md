# Webkit iOS 12.0.1 Regexec

**THIS PROJECT HAS NOT BEEN FINISHED. IT MAY CONTAIN FLAWS AND DEPENDS ON COMMUNITY CONTRIBUTIONS**

## What is this
A JIT Compiler optimization bug in regex.  
Live version: https://xtclab.nl


## Why is this public
It's a 1day, it's patched and I hate having to codesign unc0ver.  


## Credits
- Regex exploit by Linus Henze.
- Mach-O loader (+jitMemCpy) by Luca Todesco.
- Technique by Niklas Baumstark.
- Mach_Swap by Ben Sparkes, S0rryMyBad and Brandon Azad
- Int64 library by @5aelo


## Notes
- Tesmacho is not an actual payload it's 32-bit, just there for example purposes.
